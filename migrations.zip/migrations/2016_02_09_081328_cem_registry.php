<?php

use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CemRegistry extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        //
        Schema::create ('cem_registry', function(Blueprint $table){

            $table->increments('id');
            $table->string('gender');
            $table->date('dob');
            $table->integer('patient_no')->unique();
            $table->date('cem_screening');
            $table->string('cem_outcome');
            $table->string('cem_id')->unique()->nullable();
            $table->boolean('enrolled');
            $table->string('reason_nonenroll')->nullable();
            $table->string('cem_endpoint')->nullable();
            $table->date('cem_enddate')->nullable;
            $table->integer('facility_id');

        });
    }

/*Schema::table('cem_registry', function($table)
{
    $table->string('cem_id')->unique()->nullable();
});*/
    

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
