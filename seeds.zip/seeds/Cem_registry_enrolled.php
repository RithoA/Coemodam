<?php

use Illuminate\Database\Seeder;

class Cem_registry_enrolled extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('cem_registry')->insert(
        array(
        		array(
        			'gender' => 'Male',
                    'dob' =>'1994-01-29',
                    'patient_no' => '10001',
                    'cem_screening' => '2016-01-01',
                    'cem_outcome' => 'Yes',
                    'cem_id' => 'CEM/01/1001/2016/02/12',
                    'enrolled' => '1',
                    'facility_id' => '1'
                ),
                array(
                    'gender' => 'Female',
                    'dob' =>'1994-01-19',
                    'patient_no' => '1002',
                    'cem_screening' => '2016-01-01',
                    'cem_outcome' => 'Yes',
                    'cem_id' => 'CEM/02/1002/2016/02/12',
                    'enrolled' => '1',
                    'facility_id' => '2'
                ),
                array(
                    'gender' => 'Female',
                    'dob' =>'1994-01-09',
                    'patient_no' => '1003',
                    'cem_screening' => '2016-01-01',
                    'cem_outcome' => 'Yes',
                    'cem_id' => 'CEM/03/1003/2016/02/12',
                    'enrolled' => '1',
                    'facility_id' => '3'
                )

            )
    	);
    }
}
