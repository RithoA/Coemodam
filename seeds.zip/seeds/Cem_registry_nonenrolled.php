<?php

use Illuminate\Database\Seeder;

class Cem_registry_nonenrolled extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('cem_registry')->insert(
        array(
        		array(
        			'gender' => 'Male',
                    'dob' =>'1994-01-31',
                    'patient_no' => '1004',
                    'cem_screening' => '2016-01-01',
                    'cem_outcome' => 'Yes',
                    'enrolled' => '0',
                    'reason_nonenroll' => 'Declined to participate or provide informed consent',
                    'facility_id' => '1'
                )

            )
    	);
    }
}
