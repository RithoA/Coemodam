<?php

use Illuminate\Database\Seeder;

class HealthworkersTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('healthworkers')->insert(
        array(
        		array(
        			'hw_surname' => 'Oyugi',
        			'hw_firstname' => 'Onyango',
        			'eligibilityform_id' => '1'
                ),

                array(
        			'hw_surname' => 'Onyango',
        			'hw_firstname' => 'Jatelo',
        			'eligibilityform_id' => '2'
                ),

                array(
        			'hw_surname' => 'Awino',
        			'hw_firstname' => 'Anyango',
        			'eligibilityform_id' => '3'
                ),
                array(
                    'hw_surname' => 'Juma',
                    'hw_firstname' => 'Brian',
                    'eligibilityform_id' => '4'
                ),
                array(
                    'hw_surname' => 'Awino',
                    'hw_firstname' => 'Awinja',
                    'eligibilityform_id' => '5'
                )


            )
    	);
    }
}
