<?php

use Illuminate\Database\Seeder;

class Cem_registry_cem_end extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('cem_registry')->insert(
        array(
        		array(
        			'gender' => 'Male',
                    'dob' =>'1994-01-30',
                    'patient_no' => '1005',
                    'cem_screening' => '2016-01-01',
                    'cem_outcome' => 'Yes',
                    'cem_id' => 'CEM/01/1005/2016/02/12',
                    'enrolled' => '1',
                    'cem_endpoint' => 'Voluntary Exit',
                    'cem_enddate' => '2016-02-12',
                    'facility_id' => '1'
                )

            )
    	);
    }
}
