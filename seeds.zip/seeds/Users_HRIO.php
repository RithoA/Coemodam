<?php

use Illuminate\Database\Seeder;

class Users_HRIO extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert(
        array(
        		array(
                    'surname' => 'Bond',
                    'first_name' => 'James',
                    'mobile' => '0722000000',
                    'email' => 'james.bond@gmail.com',
                    'user_type' => 'Health Records Information Officer',
                    'org' => 'MOH/Faclity',
                    'county_id' => '1',
                    'fac_id' => '1',
                    'password' => bcrypt('@Jbond123'),
                    'active' => '1'
                ) ,
                array(
                    'surname' => 'Black',
                    'first_name' => 'Jack',
                    'mobile' => '0722000001',
                    'email' => 'jack.black@gmail.com',
                    'user_type' => 'Health Records Information Officer',
                    'org' => 'MOH/Faclity',
                    'county_id' => '2',
                    'fac_id' => '2',
                    'password' => bcrypt('Jblack123'),
                    'active' => '1'
                ) ,
                array(
                    'surname' => 'Jolie',
                    'first_name' => 'Angelina',
                    'mobile' => '0722000002',
                    'email' => 'angelina.jolie@gmail.com',
                    'user_type' => 'Health Records Information Officer',
                    'org' => 'MOH/Faclity',
                    'county_id' => '3',
                    'fac_id' => '3',
                    'password' => bcrypt('@Ajolie'),
                    'active' => '1'
                ) 

            )
    	);
    }
}
