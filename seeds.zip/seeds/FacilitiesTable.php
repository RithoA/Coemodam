<?php

use Illuminate\Database\Seeder;

class FacilitiesTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('facilities')->insert(
	        array(
	        		array(
	                	'fac_name' => 'Coast PGH',
	                	'county_id' => '1'
	                ),
	                array(
	                	'fac_name' => 'Machakos Level 5',
	                	'county_id' => '2'
	                ),
	                array(
	                	'fac_name' => 'Nyeri PGH',
	                	'county_id' => '3'
	                ),
	                array(
	                	'fac_name' => 'Thika Level 5',
	                	'county_id' => '4'
	                ),
	                array(
	                	'fac_name' => 'Kisii Level 5',
	                	'county_id' => '5'
	                ),
	                array(
	                	'fac_name' => 'Vihiga DH',
	                	'county_id' => '6'
	                ),
	                array(
	                	'fac_name' => 'Nakuru PGH',
	                	'county_id' => '7'
	                ),
	                array(
	                	'fac_name' => 'St Carmillus MH',
	                	'county_id' => '6'
	                )

	        )

    	);
    }
}
