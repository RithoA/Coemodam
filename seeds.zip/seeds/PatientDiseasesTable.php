<?php

use Illuminate\Database\Seeder;

class PatientDiseasesTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('patient_diseases')->insert(
        array(
        		array(
        			
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'year_start' => '2014',
        			'year_end' => '2015',
        			'disease_name' => 'Tuberculosis',
        			'date_entry' => '2016-02-12'
        			)

            )
    	);
    }
}
