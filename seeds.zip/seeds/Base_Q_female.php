<?php

use Illuminate\Database\Seeder;

class Base_Q_female extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('baseline_questionnaire')->insert(
        	array(
        		array(
        			'county_id' => '2',
        			'fac_id' => '2',
        			'clinician_surname' => 'Clinician',
        			'clinician_firstname' => 'Test',
        			'clinician_mobile' => '0722555555',
        			'date_visit' => '2016-02-12',
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'gender' => 'Female',
                    'date_birth' =>'1994-01-29',
                    'patient_no' => '1002',
                    'weight' => '59',
                    'height' => '142',
                    'bmi' => '24.1',
                    'z_score' => '5',
                    'address' => 'P.O.BOX 23452-00100',
                    'client_mobile1' => '0711000111',
                    'client_mobile2' => '0722000222',
                    'who_stage' => 'Level 2',
                    'last_lmp' => '2015-06-30',
                    'pregnant' => 'Yes',
                    'trimester' => '3',
                    'next_appointment' => '2016-03-29'
                    )

            )
    	);
    }
}
