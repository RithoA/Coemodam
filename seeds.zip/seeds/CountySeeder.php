<?php

use Illuminate\Database\Seeder;

class CountySeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
   public function run()
    {
        DB::table('counties')->insert(
            array(
                array('county_name' => 'Mombasa'),
                array('county_name' => 'Machakos'),
                array('county_name' => 'Nyeri'),
                array('county_name' => 'Kiambu'),
                array('county_name' => 'Kisii'),
                array('county_name' => 'Vihiga'),
                array('county_name' => 'Nakuru')

            )
        );
    }
}
