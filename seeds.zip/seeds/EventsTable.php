<?php

use Illuminate\Database\Seeder;

class EventsTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('events')->insert(
        array(
        		array(
        			
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'onset_date' => '2015-09-12',
        			'severity' => 'Average',
        			'outcome' => 'asdfg',
        			'rechallenge' => 'None',
        			'rechallenge_response' => 'None'
        			
                )

            )
    	);
    }
}
