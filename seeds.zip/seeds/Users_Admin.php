<?php

use Illuminate\Database\Seeder;

class Users_Admin extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert(
        array(
        		array(
                	'surname' => 'Doe',
                	'first_name' => 'John',
                	'mobile' => '071106600',
                	'email' => 'john.doe@gmail.com',
                	'user_type' => 'Administrator',
                	'org' => 'MOH/Nascop',
                   	'password' => bcrypt('@Jdoe123'),
                    'active' => '1'
                ),

                array(
                    'surname' => 'Sakaja',
                    'first_name' => 'James',
                    'mobile' => '071106601',
                    'email' => 'james.sakaja@gmail.com',
                    'user_type' => 'Administrator',
                    'org' => 'MOH/PPB',
                    'password' => bcrypt('@Jsakaja123'),
                    'active' => '1'
                ),
                array(
                    'surname' => 'Jane',
                    'first_name' => 'Mary',
                    'mobile' => '071106602',
                    'email' => 'mary.jane@gmail.com',
                    'user_type' => 'Administrator',
                    'org' => 'MSH',
                    'password' => bcrypt('@Jmary123'),
                    'active' => '1'
                ),



            )
    	);
    }
}
