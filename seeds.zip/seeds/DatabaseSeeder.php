<?php

use Illuminate\Database\Seeder;
use Illuminate\Database\Eloquent\Model;

class DatabaseSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        
       // Model::unguard();

        $this->call(CountySeeder::class);
        $this->call(FacilitiesTable::class);
        $this->call(Users_Admin::class);
        $this->call(Users_CEM::class);
        $this->call(Users_HRIO::class);

        $this->call(Cem_registry_cem_end::class);
        $this->call(Cem_registry_enrolled::class);
        $this->call(Cem_registry_nonenrolled::class);
        $this->call(Cem_entriesTable::class);

        $this->call(Base_Q_male::class);        
        $this->call(Base_Q_female::class);
        $this->call(Base_Pregnancy::class);        
        $this->call(ART_start::class);
        $this->call(ART_follow::class);

        $this->call(EventsTable::class);
        $this->call(HealthworkersTable::class);
        $this->call(P_Progress::class);
        $this->call(P_Outcome::class);
        $this->call(PatientLabTestsTable::class);
        $this->call(PatientArtDrugsTable::class);
        $this->call(PatientDiseasesTable::class);
        $this->call(PatientDrugsTable::class);


        //Model::reguard();
    }
}

