<?php

use Illuminate\Database\Seeder;

class P_Progress extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('pregnancy_progress')->insert(
            array(
        		array(
        			'clinician_surname' => 'Clinician',
        			'clinician_firstname' => 'Test',
        			'clinician_mobile' => '0722555555',
        			'date_visit' => '2016-03-29',
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'weight' => '59',
        			'anc_name' => 'abcdef',
        			'gestation' => '36',
        			'abnormalities_pg' => 'qwerty',
        			'abnormalities_onset' => '2015-11-06',
        			'baby_born' => 'Yes',
        			'baby_birthplace' => 'Jamaa Hospital',
        			'baby_dob' => '2016-02-11',
        			'miscarriage' => 'No',
        			'miscarriage_date' => 'None',
           			'filled_by' => 'Alice Wonderland',
        			'filled_mobile' => '07123454678',
        			'filled_date' => '2016-03-29',
        			'anc_next' => '2016-04-29'
                )

            )
    	);
    }
}
