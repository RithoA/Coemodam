<?php

use Illuminate\Database\Seeder;

class PatientLabTestsTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('patient_labtests')->insert(
        array(
        		array(
        			
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'test_name' => 'Elisa III',
        			'test_date' => '2015-07-14',
        			'test_result' => 'Positive',
        			'date_entry' => '2016-02-12'
        			)

            )
    	);
    }
}
