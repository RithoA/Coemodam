<?php

use Illuminate\Database\Seeder;

class PatientDrugsTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('patient_drugs')->insert(
        array(
        		array(
        			'drug_name' => 'lexotanil',
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'drug_entry' => '2016-01-24'
                )

            )
    	);
    }
}
