<?php

use Illuminate\Database\Seeder;

class Base_Q_male extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('baseline_questionnaire')->insert(
        array(
        		array(
        			'county_id' => '1',
        			'fac_id' => '1',
        			'clinician_surname' => 'Clinician',
        			'clinician_firstname' => 'Test',
        			'clinician_mobile' => '0722555555',
        			'date_visit' => '2016-02-12',
        			'cem_id' => 'CEM/01/1001/2016/02/12',
        			'gender' => 'Male',
                    'date_birth' =>'1994-01-29',
                    'patient_no' => '1001',
                    'weight' => '59',
                    'height' => '172',
                    'bmi' => '24.1',
                    'z_score' => '5',
                    'address' => 'P.O.BOX 23452-00100',
                    'client_mobile1' => '0711000111',
                    'client_mobile2' => '0722000222',
                    'who_stage' => 'Level 2',
                    'next_appointment' => '2016-03-29'
                    )
                
            )
    	);
    }
}
