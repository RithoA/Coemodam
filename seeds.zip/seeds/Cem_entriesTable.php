<?php

use Illuminate\Database\Seeder;

class Cem_entriesTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('cem_entries')->insert(
        array(
        		array(
        			'cem_entryno' => '1',
        			'hrio_email' => 'james.bond@gmail.com',
        			'fac_id' => '1',
        			'entry' => '2016-02-12 12:17:47'
                ),

                array(
        			'cem_entryno' => '2',
        			'hrio_email' => 'jack.black@gmail.com',
        			'fac_id' => '2',
        			'entry' => '2016-02-12 12:19:07'
                ),

                array(
        			'cem_entryno' => '3',
        			'hrio_email' => 'angelina.jolie@gmail.com',
        			'fac_id' => '3',
        			'entry' => '2016-02-12 12:29:59'
                ),
                array(
                    'cem_entryno' => '4',
                    'hrio_email' => 'james.bond@gmail.com',
                    'fac_id' => '1',
                    'entry' => '2016-02-12 12:39:59'
                ),
                array(
                    'cem_entryno' => '5',
                    'hrio_email' => 'james.bond@gmail.com',
                    'fac_id' => '1',
                    'entry' => '2016-02-12 12:49:59'
                )



            )
    	);
    }
}
