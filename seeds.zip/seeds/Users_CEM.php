<?php

use Illuminate\Database\Seeder;

class Users_CEM extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('users')->insert(
        array(
        		array(
                    'surname' => 'Doe',
                    'first_name' => 'Jane',
                    'mobile' => '072206600',
                    'email' => 'jane.doe@gmail.com',
                    'user_type' => 'CEM focal person',
                    'org' => 'MOH/County',
                    'county_id' => '1',
                    'password' => bcrypt('@Jdoe123'),
                    'active' => '1'
                ),
                array(
                    'surname' => 'West',
                    'first_name' => 'Kanye',
                    'mobile' => '072206601',
                    'email' => 'kanye.west@gmail.com',
                    'user_type' => 'CEM focal person',
                    'org' => 'MOH/County',
                    'county_id' => '2',
                    'password' => bcrypt('@Kwest123'),
                    'active' => '1'
                ),
                array(
                    'surname' => 'Kimnye',
                    'first_name' => 'Kim',
                    'mobile' => '072206602',
                    'email' => 'kim.kimnye@gmail.com',
                    'user_type' => 'CEM focal person',
                    'org' => 'MOH/County',
                    'county_id' => '3',
                    'password' => bcrypt('@Kkimnye123'),
                    'active' => '1'
                )

            )
    	);
    }
}
