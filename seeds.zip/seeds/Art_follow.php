<?php

use Illuminate\Database\Seeder;

class Art_follow extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('art_followup')->insert(
        array(
        		array(
        			'clinician_surname' => 'Test',
        			'clinician_firstname' => 'Clinician',
        			'clinician_mobile' => '0712364569',
        			'died' => 'No',
        			'lost_followup' => 'No',
        			'date_visit' => '2016-03-29',
        			'cem_id' => 'CEM/01/1001/2016/02/12',
        			'weight' => '59',
                    'height' => '172',
                    'bmi' => '24.1',
                    'z_score' => '5',
                    'who_stage' => 'Level 2',
                    'filled_by' => 'James Bond',
                    'filled_mobile' => '0722000000',
                    'next_appointment' => '2016-04-29'

                    )

            )
    	);
    }
}
