<?php

use Illuminate\Database\Seeder;

class PatientArtDrugsTable extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('patient_art_drugs')->insert(
        array(
        		array(
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'date_stopped' => '2015-08-26',
        			'reason' => 'Reacts with featus',
        			'date_restarted' => '2015-10-05',
        			'date_entry' => '2016-02-12'

        			)

            )
    	);
    }
}
