<?php

use Illuminate\Database\Seeder;

class Base_Pregnancy extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('pregnancy_baseline')->insert(
        array(
        		array(
        			'clinician_surname' => 'Clinician',
        			'clinician_firstname' => 'Test',
        			'clinician_mobile' => '0722555555',
        			'date_visit' => '2016-02-12',
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'weight' => '59',
        			'art_commence' => '2015-11-30',
        			'last_lmp' => '30-06-2015',
        			'first_movements' => '2015-08-15',
        			'pregnancy_anc' => 'Yes',
        			'anc_name' => 'abcde',
        			'trimester_art' => '1',
        			'gestation' => '30',
        			'past_pg' => '2',
        			'live_babies' => '2',
        			'abnormalities_pg' => 'qwerty',
        			'abnormalities_onset' => '2015-11-06',
        			'filled_by' => 'Alice Wonderland',
        			'filled_mobile' => '07123454678',
        			'filled_date' => '2016-02-12',
        			'anc_next' => '2016-03-29'
                )

            )
    	);
    }
}
