<?php

use Illuminate\Database\Seeder;

class P_Outcome extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
        DB::table('pregnancy_outcome')->insert(
        array(
        		array(
        			'cem_id' => 'CEM/02/1002/2016/02/12',
        			'delivery_place' => 'Jamaa Hospital',
        			'patientno_delivery' => 'J1101',
        			'contact_delivery' => 'Dr. Khalwale',
        			'art_delivery' => 'Yes',
        			'arvs' => 'abc',
        			'delivery_date' => '2016-02-11',
        			'miscarriage' => 'No',
        			'miscarriage_date' => '0000-00-00',
        			'abnormalities_pg' => 'qwerty',
        			'abnormalities_labour' => 'None',
        			'abnormalities_baby' => 'None',
        			'filled_by' => 'Alice Wonderland',
        			'filled_mobile' => '07123454678',
        			'filled_date' => '2016-03-29',
        			'anc_next' => '2016-04-29'

                )

            )
    	);
    }
}
